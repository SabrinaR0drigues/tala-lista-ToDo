import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const TabelaExemplo = () => {
  const [dados, setDados] = useState([
    { id: '1', nome: 'Sr. Karan', valor: '100' },
    { id: '2', nome: 'Maria', valor: '200' },
    { id: '3', nome: 'João', valor: '300' }
  ]);

  const renderItem = ({ item }) => (
    <View style={styles.row}>
      <Text style={styles.cell}>{item.id}</Text>
      <Text style={styles.cell}>{item.nome}</Text>
      <Text style={styles.cell}>R$ {item.valor}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>ID</Text>
        <Text style={styles.headerText}>Nome</Text>
        <Text style={styles.headerText}>Valor</Text>
      </View>
      <FlatList
        data={dados}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  header: {
    flexDirection: 'row',
    backgroundColor: '#ddd',
    padding: 10,
  },
  headerText: {
    flex: 1,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  row: {
    flexDirection: 'row',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  cell: {
    flex: 1,
    textAlign: 'center',
  },
});

export default TabelaExemplo;